import {voteWithLuna} from './src/utils/openai';
import {planSession,countBallots,ballotOf} from './src/utils/plenary';
import {evaluateVotingResult,resolveTieBreak} from './src/utils/votingAlgorithm';
import {parseWorkspace,closeLegislature,openLegislature,importReform} from './src/utils/legislatures';
import {reconsiderationBlock,finalizeMotion,isMotionDefinitive} from './src/utils/procedure';

const host = globalThis as any;
host.crypto = {randomUUID: () => host.nativeUUID()};
const listeners = new Map();
host.window = {
  AndroidExport:{requestOpenAI:(id:string,_key:string,body:string)=>host.nativeRequest(id,body)},
  setTimeout:()=>0, clearTimeout:()=>{},
  addEventListener:(name:string,fn:any)=>listeners.set(name,fn),
  removeEventListener:(name:string)=>listeners.delete(name),
};
host.deliver = (id:string,raw:string,error:string)=>{
  const name='openai-'+id, listener=listeners.get(name);
  listeners.delete(name);
  listener?.({detail:{raw,error}});
};
host.runLuna = (input:string)=>{
  const {plan,motion,legislature,archives,debate,reconsideration,revision} = JSON.parse(input);
  let closure;
  voteWithLuna('',plan,motion,legislature.parties,legislature.countryContext,reconsideration,debate,
    [...archives,legislature],revision,legislature.congressmen,(article,reason)=>{closure={article,reason}})
    .then(ballots=>host.nativeComplete(JSON.stringify({ballots,closure}), ''),
      error=>host.nativeComplete('', String(error.message ?? error)));
};
const operations = {planSession,countBallots,ballotOf,evaluateVotingResult,resolveTieBreak,parseWorkspace,
  closeLegislature,openLegislature,importReform,reconsiderationBlock,finalizeMotion,isMotionDefinitive};
host.run = (name:keyof typeof operations,args:string)=>JSON.stringify((operations[name] as any)(...JSON.parse(args)) ?? null);
