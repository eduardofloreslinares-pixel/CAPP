# Congreso Virtual para iOS

Aplicación para iPhone y iPad con interfaz nativa en SwiftUI y Liquid Glass. Requiere iOS 26 o posterior.

## Compilar en GitHub

1. Si tu repositorio ya compila desde el ZIP, sube la nueva versión de `Congreso-Virtual-iOS.zip` con el mismo nombre. Para configurar un repositorio nuevo, descomprime el ZIP y sube su contenido, incluida la carpeta oculta `.github`.
2. Abre **Actions → Compilar Congreso iOS → Run workflow**.
3. Al terminar, descarga **Congreso-Virtual-IPA**, descomprímelo y abre el IPA en SideStore para firmarlo e instalarlo.

El IPA producido por Actions se entrega sin firma. Para actualizar una instalación, conserva el identificador del paquete y utiliza la misma cuenta y configuración de firma en SideStore.

## Datos y uso

La instalación limpia comienza con el Período Legislativo I, los 51 congresistas originales y sus ocho bancadas. Para llevar una partida desde Android, exporta el respaldo JSON de Congreso Virtual y ábrelo desde **Ajustes → Importar respaldo**. La importación reemplaza el espacio de trabajo de iOS.

En **Ajustes**, guarda la clave del proyecto de OpenAI para usar GPT‑6 Luna. El llavero de iOS guarda la clave.

Al crear o editar una iniciativa, usa **Contexto de la moción** para fijar los hechos que el pleno dará por ciertos dentro de tu república personal.

La interfaz, persistencia, llavero y red son nativos. El archivo `App/Rules.js` reutiliza el motor legislativo y las reglas de simulación de Android mediante JavaScriptCore. `EngineBridge.ts` documenta el enlace con el código de Android. El archivo JavaScript ya está incluido en el proyecto, por lo que el flujo de compilación de iOS no requiere Node.
