import SwiftUI
import UIKit
import UniformTypeIdentifiers

@main @MainActor struct CongresoApp: App {
    @StateObject private var store = CongressStore()
    var body: some Scene {
        WindowGroup { CongresoHome().environmentObject(store) }
    }
}

let amber = Color(red:0.88,green:0.49,blue:0.17)
let motionTypes = [
    ("proyecto_ley","Proyecto de ley"),("reforma_constitucional","Reforma constitucional"),
    ("vacancia","Vacancia"),("desafuero","Desafuero"),("mocion_orden","Moción de orden"),
    ("censura_mesa_directiva","Censura de Mesa Directiva"),("censura_ministro","Censura ministerial"),
    ("interpelacion","Interpelación"),("declaracion_urgencia","Declaratoria de emergencia")
]
let majorities = [("simple","Simple"),("absoluta","Absoluta"),("dos_tercios","Dos tercios"),("tres_quintos","Tres quintos")]
let positions = [("economy","Economía"),("security","Seguridad"),("socialRights","Derechos sociales"),("institutional","Institucionalidad"),("environment","Medio ambiente"),("decentralization","Descentralización"),("taxation","Tributación"),("labor","Trabajo"),("executiveSupport","Respaldo al Ejecutivo")]
func label(_ code: String) -> String {
    (motionTypes+majorities).first{$0.0==code}?.1 ?? code.replacingOccurrences(of:"_",with:" ").capitalized
}
func voteColor(_ code: String) -> Color {
    switch code {
    case "a_favor": .green
    case "en_contra": .red
    case "abstencion": amber
    case "ausente": .gray
    case "incidente": .purple
    default: .secondary
    }
}
extension Color {
    init(hex: String) {
        let rgb = UInt64(hex.trimmingCharacters(in:CharacterSet(charactersIn:"#")),radix:16) ?? 0x888888
        self.init(red:Double((rgb>>16)&255)/255,green:Double((rgb>>8)&255)/255,blue:Double(rgb&255)/255)
    }
}
struct GlassCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment:.leading,spacing:14) { content }
            .frame(maxWidth:.infinity,alignment:.leading)
            .padding(18)
            .glassEffect(.regular,in:.rect(cornerRadius:25))
    }
}
struct PageBackground: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        ZStack(alignment:.top) {
            Color(uiColor:.systemGroupedBackground)
            RadialGradient(colors:[amber.opacity(scheme == .dark ? 0.22 : 0.18),.clear],center:.topLeading,startRadius:0,endRadius:400)
            RadialGradient(colors:[Color.indigo.opacity(scheme == .dark ? 0.24 : 0.12),.clear],center:.bottomTrailing,startRadius:0,endRadius:420)
        }.ignoresSafeArea()
    }
}
struct CongresoHome: View {
    @EnvironmentObject var store: CongressStore
    @State private var tab = "pleno"
    var body: some View {
        TabView(selection:$tab) {
            Tab("Pleno",systemImage:"building.columns",value:"pleno") { PlenoView() }
            Tab("Agenda",systemImage:"list.bullet.rectangle",value:"agenda") { AgendaView { tab = "pleno" } }
            Tab("Bancadas",systemImage:"person.3",value:"bancadas") { MembersView() }
            Tab("Diario",systemImage:"book.closed",value:"diario") { DiaryView() }
            Tab("Ajustes",systemImage:"gearshape",value:"ajustes") { SettingsView() }
        }
        .tint(amber)
        .alert("Congreso Virtual",isPresented:Binding(get:{store.error != nil},set:{if !$0 {store.error=nil}})) {
            Button("Aceptar",role:.cancel) { store.error=nil }
        } message: { Text(store.error ?? "") }
    }
}

struct PlenoView: View {
    @EnvironmentObject var store: CongressStore
    @State private var dialog = ""
    @State private var message = ""
    @State private var article = ""
    @State private var selectedRound: Int?
    var rounds: [Record] { store.motion.rows("rounds") }
    var shownVotes: Record {
        if store.isLive { return store.ballots }
        if let selectedRound, rounds.indices.contains(selectedRound) { return rounds[selectedRound].record("votes") }
        return rounds.last?.record("votes") ?? [:]
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                GlassEffectContainer(spacing:18) {
                    LazyVStack(spacing:18) {
                        GlassCard {
                            Label(store.current.string("name"),systemImage:"building.columns.fill")
                                .font(.system(.title2,design:.serif,weight:.semibold))
                            Text(store.current.string("period")).foregroundStyle(.secondary)
                            if !store.isLive && rounds.count > 1 {
                                Picker("Ronda del hemiciclo",selection:$selectedRound) {
                                    Text("Última ronda").tag(nil as Int?)
                                    ForEach(rounds.indices,id:\.self) { index in
                                        Text("Ronda \(rounds[index].number("roundNumber"))").tag(Optional(index))
                                    }
                                }
                                .pickerStyle(.segmented)
                            }
                            Hemicycle(votes:shownVotes)
                            if store.members.isEmpty { Text("Incorpora congresistas desde Bancadas.").foregroundStyle(.secondary) }
                        }
                        if store.motion.isEmpty {
                            ContentUnavailableView("El Pleno está en espera",systemImage:"doc.text",description:Text("Selecciona o presenta una moción en Agenda."))
                        } else {
                            subject
                            if store.isLive {
                                if store.phase == "debate" { debatePanel }
                                else {
                                    votingPanel
                                    if !store.speeches.isEmpty { debateTranscript }
                                }
                            }
                            if !rounds.isEmpty || !store.motion.rows("reconsiderationRequests").isEmpty {
                                RoundHistory(motion:store.motion)
                            }
                        }
                    }.padding(.horizontal,16).padding(.vertical,14)
                }
            }
            .background { PageBackground() }
            .navigationTitle("Hemiciclo")
            .onChange(of:store.activeID) { selectedRound = nil }
            .sheet(isPresented:Binding(get:{!dialog.isEmpty},set:{if !$0 {dialog=""}})) {
                NavigationStack {
                    Form {
                        if dialog == "Inadmisibilidad" { TextField("Artículo del reglamento",text:$article) }
                        TextField("Fundamento o mensaje",text:$message,axis:.vertical).lineLimit(4...10)
                    }
                    .navigationTitle(dialog)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { dialog="" } }
                        ToolbarItem(placement:.confirmationAction) {
                            Button("Confirmar") { submit() }.disabled(message.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                        }
                    }
                }.presentationDetents([.medium,.large])
            }
        }
    }
    var subject: some View {
        GlassCard {
            Text(label(store.motion.string("type"))).font(.caption.weight(.semibold)).foregroundStyle(amber)
            Text(store.motion.string("title")).font(.system(.title2,design:.serif,weight:.semibold))
            Text(store.motion.string("text")).font(.callout).foregroundStyle(.secondary)
            if !store.motion.string("factualContext").isEmpty {
                DisclosureGroup("Contexto de la moción") {
                    Text(store.motion.string("factualContext")).font(.callout).textSelection(.enabled)
                }
            }
            Label(store.motion.record("proposedBy").string("name"),systemImage:"person.2")
                .font(.footnote)
            if !store.motion.record("pendingReconsideration").isEmpty { Text("Votación de admisión previa a la nueva ronda").font(.footnote.bold()).foregroundStyle(amber) }
            if store.motion.string("status") == "inadmisible" {
                Text(store.motion.record("inadmissibilityReason").string("details")).foregroundStyle(.red)
            }
            if store.canStart && !store.isLive {
                if store.busy { ProgressView("Preparando pleno…") }
                else {
                    ViewThatFits(in:.horizontal) {
                        HStack { startButtons }
                        VStack(alignment:.leading) { startButtons }
                    }
                }
            }
            if let issue = store.motion["definitive"] as? Bool, issue { Label("Moción definitiva",systemImage:"lock.fill").font(.footnote) }
            if !store.isClosed && !store.busy && store.motion.string("status") != "inadmisible" {
                if !store.isLive && !rounds.isEmpty && store.reconsiderationIssue.isEmpty && !store.motion.flag("reconsiderationAuthorized") {
                    Button("Solicitar reconsideración",systemImage:"arrow.counterclockwise") { prompt("Reconsideración") }.buttonStyle(.glass)
                }
                if store.canStart {
                    Button("Negociar",systemImage:"bubble.left.and.bubble.right") { prompt("Negociación") }.buttonStyle(.glass)
                }
            }
        }
    }
    @ViewBuilder var startButtons: some View {
        Button("Abrir debate",systemImage:"quote.bubble") { Task { await store.begin(debate:true) } }.buttonStyle(.glassProminent)
        Button("Votar",systemImage:"checkmark.circle") { Task { await store.begin(debate:false) } }.buttonStyle(.glass)
    }
    var debatePanel: some View {
        VStack(alignment:.leading,spacing:12) {
            GlassCard {
                Text("Debate del pleno").font(.title3.bold())
                if store.busy { ProgressView("Preparando pleno…") }
                else {
                    Button("Pasar a votación",systemImage:"checkmark.circle") { store.rollingVote() }.buttonStyle(.glassProminent)
                    if !store.speechQueue.isEmpty {
                        Button(store.debatePaused ? "Reanudar debate" : "Pausar debate") { store.toggleDebate() }.buttonStyle(.glass)
                    } else { Text("El debate ha concluido").foregroundStyle(.secondary) }
                    Button("Intervención de la Mesa",systemImage:"mic") { prompt("Mesa Directiva") }.buttonStyle(.glass)
                    Button("Declarar inadmisible",systemImage:"exclamationmark.shield") { prompt("Inadmisibilidad") }.buttonStyle(.glass)
                }
            }
            if let speaker = store.speechQueue.first, !store.liveSpeech.isEmpty {
                SpeechCard(speech:speaker,text:store.liveSpeech,members:store.members,parties:store.parties)
            }
            speechRows
        }
    }
    var debateTranscript: some View {
        VStack(alignment:.leading,spacing:12) {
            Text("Debate del pleno").font(.title3.bold())
            speechRows
        }
    }
    var speechRows: some View {
        ForEach(Array(store.speeches.enumerated().reversed()),id:\.offset) { _, speech in
            SpeechCard(speech:speech,text:speech.string("text"),members:store.members,parties:store.parties)
        }
    }
    var votingPanel: some View {
        GlassCard {
            let counts = store.counts
            Text("Votación nominal").font(.title3.bold())
            VoteProgress(counts:counts,total:store.plan.count)
            Tally(counts:counts)
            if store.busy {
                ProgressView("Reevaluando la negociación…")
            } else {
                if store.votingComplete {
                    let cast = counts.number("aFavor") + counts.number("enContra") + counts.number("abstencion")
                    Label(cast == 0 ? "Registro completo · sin votos emitidos" : "Ya votaron todos los congresistas habilitados",
                          systemImage:"checkmark.circle.fill")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.green)
                    Text("Cierra la votación para registrar el resultado.").font(.caption).foregroundStyle(.secondary)
                } else {
                    Text("\(store.ballots.count) de \(store.plan.count) registros")
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                }
                ViewThatFits(in:.horizontal) {
                    HStack { primaryVotingActions }
                    VStack(alignment:.leading) { primaryVotingActions }
                }
                ViewThatFits(in:.horizontal) {
                    HStack { secondaryVotingActions }
                    VStack(alignment:.leading) { secondaryVotingActions }
                }
            }
            if !store.ballots.isEmpty {
                Divider()
                Text("Detalle por congresista").font(.headline)
                VoteRows(votes:store.ballots,members:store.members,parties:store.parties)
            }
        }
        .controlSize(.small)
    }
    @ViewBuilder var primaryVotingActions: some View {
        if !store.votingComplete {
            Button(store.paused ? "Reanudar" : "Quinto intermedio",systemImage:store.paused ? "play.fill":"pause.fill") {
                store.togglePause()
            }.buttonStyle(.glass).fixedSize()
        }
        Button("Cerrar votación",systemImage:"checkmark.seal") { store.finish() }
            .buttonStyle(.glassProminent).fixedSize()
    }
    @ViewBuilder var secondaryVotingActions: some View {
        if store.motion.record("pendingReconsideration").isEmpty {
            Button("Veto presidencial",systemImage:"hand.raised") { prompt("Veto presidencial") }
                .buttonStyle(.glass).fixedSize()
        }
        Button("Declarar inadmisible",systemImage:"exclamationmark.shield") { prompt("Inadmisibilidad") }
            .buttonStyle(.glass).fixedSize()
    }
    func prompt(_ value: String) {
        message = value == "Negociación" ? store.motion.string("negotiations") : ""
        article = ""
        dialog = value
    }
    func submit() {
        let action = dialog
        let text = message
        dialog = ""
        switch action {
        case "Reconsideración": store.reconsider(text)
        case "Mesa Directiva": Task { await store.begin(debate:true,message:text) }
        case "Inadmisibilidad": store.declareInadmissible(article,text)
        case "Veto presidencial": store.finish(veto:text)
        case "Negociación":
            Task { await store.saveNegotiation(text) }
        default: break
        }
    }
}

struct Hemicycle: View {
    @EnvironmentObject var store: CongressStore
    let votes: Record
    var body: some View {
        VStack(spacing:12) {
            Canvas { context, size in
                let center = CGPoint(x:size.width/2,y:size.height-15)
                let radius = min(size.width*0.46,size.height-18)
                let count = store.members.count
                let ringCount = count > 51 ? 5 : count > 20 ? 3 : count > 8 ? 2 : 1
                let weights = (0..<ringCount).map { 0.50 + Double($0 + 1) * 0.50 / Double(ringCount) }
                let weightTotal = weights.reduce(0,+)
                var allocated = 0
                var accumulated = 0.0
                var seats: [(Double, CGFloat)] = []
                for weight in weights {
                    accumulated += weight
                    let next = Int((Double(count) * accumulated / weightTotal).rounded())
                    let ringSeats = next - allocated
                    allocated = next
                    for seat in 0..<ringSeats {
                        let angle = Double.pi * (Double(seat) + 0.5) / Double(ringSeats)
                        seats.append((angle,radius * CGFloat(weight)))
                    }
                }
                seats.sort { $0.0 > $1.0 }
                let members = store.members.sorted {$0.number("seatIndex")<$1.number("seatIndex")}
                for (member,slot) in zip(members,seats) {
                    let x = center.x + CGFloat(cos(slot.0)) * slot.1
                    let y = center.y - CGFloat(sin(slot.0)) * slot.1
                    let party = store.parties.first{$0.string("id")==member.string("partyId")}
                    let code = votes.record(member.string("id")).string("vote")
                    let dot: CGFloat = store.members.count > 51 ? 5 : 8
                    let rect = CGRect(x:x-dot/2,y:y-dot/2,width:dot,height:dot)
                    context.fill(Path(ellipseIn:rect),with:.color(code.isEmpty ? Color(hex:party?.string("color") ?? "") : voteColor(code)))
                }
                let icon = context.resolve(Image(systemName:"building.columns.fill"))
                context.draw(icon,at:CGPoint(x:center.x,y:center.y-5))
            }.frame(height:165)
            .accessibilityLabel("Hemiciclo · \(store.members.count) curules")
            ScrollView(.horizontal) {
                HStack(spacing:12) {
                    ForEach(store.parties.indices,id:\.self) { index in
                        let party = store.parties[index]
                        Label(party.string("shortName"),systemImage:"circle.fill")
                            .font(.caption.weight(.semibold)).foregroundStyle(Color(hex:party.string("color")))
                    }
                }
            }.scrollIndicators(.hidden)
        }
    }
}
struct PartyBadge: View {
    let party: Record

    var body: some View {
        Label(party.string("shortName"),systemImage:"circle.fill")
            .font(.caption.weight(.semibold))
            .foregroundStyle(Color(hex:party.string("color")))
            .imageScale(.small)
            .accessibilityLabel(party.string("name"))
    }
}

struct SpeechCard: View {
    let speech: Record
    let text: String
    let members: [Record]
    let parties: [Record]

    var body: some View {
        let name = speech.string("name")
        let member = members.first { $0.string("id") == speech.string("id") }
            ?? members.first { $0.string("name") == name }
        let partyID = speech.string("partyId").isEmpty ? member?.string("partyId") : speech.string("partyId")
        let party = parties.first { $0.string("id") == partyID }
        VStack(alignment:.leading,spacing:8) {
            HStack(alignment:.firstTextBaseline) {
                Text(name).font(.subheadline.weight(.semibold))
                Spacer(minLength:4)
                if let party { PartyBadge(party:party) }
            }
            Text(text).font(.callout).textSelection(.enabled)
        }
        .frame(maxWidth:.infinity,alignment:.leading)
        .padding(12)
        .glassEffect(.regular,in:.rect(cornerRadius:16))
    }
}

private let tallyCategories: [(key:String,title:String,vote:String)] = [
    ("aFavor","A favor","a_favor"),("enContra","En contra","en_contra"),("abstencion","Abstención","abstencion"),
    ("ausente","Ausentes","ausente"),("noEmitidos","Incidentes","incidente")
]

struct VoteProgress: View {
    let counts: Record
    let total: Int
    var body: some View {
        GeometryReader { geometry in
            let unit = geometry.size.width / CGFloat(max(1,total))
            ZStack(alignment:.leading) {
                Rectangle().fill(.quaternary)
                HStack(spacing:0) {
                    ForEach(tallyCategories.indices,id:\.self) { index in
                        let category = tallyCategories[index]
                        Rectangle().fill(voteColor(category.vote))
                            .frame(width:unit * CGFloat(counts.number(category.key)))
                    }
                }
            }
        }
        .frame(height:6)
        .clipShape(Capsule())
        .accessibilityHidden(true)
    }
}

struct Tally: View {
    let counts: Record
    var body: some View {
        LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible()),GridItem(.flexible())],spacing:12) {
            ForEach(tallyCategories.indices,id:\.self) { index in
                let category = tallyCategories[index]
                VStack(alignment:.leading) {
                    Text(counts.number(category.key).formatted()).font(.title2.bold().monospacedDigit())
                    Text(category.title).font(.caption).foregroundStyle(voteColor(category.vote))
                }.frame(maxWidth:.infinity,alignment:.leading)
            }
        }
    }
}
struct VoteRows: View {
    let votes: Record
    let members: [Record]
    let parties: [Record]
    var body: some View {
        ForEach(votes.keys.sorted(by:isMoreRecent),id:\.self) { id in
            let ballot = votes.record(id)
            let code = ballot.string("vote")
            let member = members.first { $0.string("id") == id }
            let partyID = ballot.string("partyId").isEmpty ? member?.string("partyId") : ballot.string("partyId")
            let party = parties.first { $0.string("id") == partyID }
            let glass: Glass = ["a_favor","en_contra"].contains(code)
                ? .regular.tint(voteColor(code).opacity(0.17)) : .regular
            let explanation = [ballot.string("incident"),ballot.string("influence"),ballot.string("speech")]
                .first { !$0.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty }
            VStack(alignment:.leading,spacing:5) {
                HStack(alignment:.firstTextBaseline) {
                    Text(member?.string("name") ?? id).font(.subheadline.weight(.semibold))
                    Spacer(minLength:8)
                    if let party { PartyBadge(party:party) }
                }
                Text(label(code)).font(.footnote.weight(.medium)).foregroundStyle(voteColor(code))
                if let explanation {
                    Text(explanation).font(.footnote).foregroundStyle(.secondary)
                }
            }
            .frame(maxWidth:.infinity,alignment:.leading)
            .padding(12)
            .glassEffect(glass,in:.rect(cornerRadius:16))
        }
    }
    private func isMoreRecent(_ lhs: String,_ rhs: String) -> Bool {
        let left = votes.record(lhs)
        let right = votes.record(rhs)
        return (left.number("timestamp"),left.number("recordedOrder"),lhs)
            > (right.number("timestamp"),right.number("recordedOrder"),rhs)
    }
}
struct RoundHistory: View {
    @EnvironmentObject var store: CongressStore
    let motion: Record
    var members: [Record]? = nil
    var parties: [Record]? = nil
    var body: some View {
        let rounds = motion.rows("rounds")
        let requests = motion.rows("reconsiderationRequests")
        ForEach(rounds.indices.reversed(),id:\.self) { index in
            let round = rounds[index]
            VStack(alignment:.leading,spacing:12) {
                GlassCard {
                    Text("Ronda \(round.number("roundNumber")) · \(label(round.string("result")))").font(.headline)
                    voteDetails(round)
                }
                transcript(round)
            }
        }
        ForEach(requests.indices.reversed(),id:\.self) { index in
            let round = requests[index].record("round")
            VStack(alignment:.leading,spacing:12) {
                GlassCard {
                    Text("Admisión de reconsideración · \(index+1)").font(.headline)
                    Text(requests[index].string("reason")).font(.callout)
                    voteDetails(round)
                }
                transcript(round)
            }
        }
    }
    @ViewBuilder func voteDetails(_ round: Record) -> some View {
        Tally(counts:round.record("counts"))
        if !round.record("votes").isEmpty {
            Text("Registro de votos").font(.headline)
            VoteRows(votes:round.record("votes"),members:members ?? store.members,parties:parties ?? store.parties)
        }
    }
    @ViewBuilder func transcript(_ round: Record) -> some View {
        if !round.rows("debate").isEmpty {
            DisclosureGroup("Acta del debate") {
                VStack(spacing:12) {
                    ForEach(Array(round.rows("debate").enumerated()),id:\.offset) { _, speech in
                        SpeechCard(speech:speech,text:speech.string("text"),members:members ?? store.members,parties:parties ?? store.parties)
                    }
                }
                .padding(.top,8)
            }
            .padding(.horizontal,4)
        }
    }
}
