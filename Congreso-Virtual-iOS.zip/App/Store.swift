import SwiftUI

@MainActor final class CongressStore: ObservableObject {
    @Published var workspace: Record = [:]
    @Published var activeID = ""
    @Published var plan: [Record] = []
    @Published var ballots: Record = [:]
    @Published var speeches: [Record] = []
    @Published var debatePaused = false
    @Published var liveSpeech = ""
    @Published var speechQueue: [Record] = []
    private var debateTask: Task<Void, Never>?
    @Published var busy = false
    @Published var paused = false
    @Published var error: String?
    @Published var phase = "lista"
    private var engine: Engine?
    private var interval: Task<Void, Never>?
    private let location = URL.applicationSupportDirectory.appending(path: "Congreso.json")

    init() {
        do {
            engine = try Engine()
            let source = FileManager.default.fileExists(atPath: location.path) ? location : Bundle.main.url(forResource:"PeriodOne",withExtension:"json")!
            guard let saved = try JSONSerialization.jsonObject(with: Data(contentsOf: source)) as? Record else {
                throw CongressError(message:"No se pudo leer el archivo del Congreso.")
            }
            workspace = saved
            if assignMissingPartyColors() { save() }
            select(UserDefaults.standard.string(forKey:"activeMotion") ?? "")
        } catch { self.error = error.localizedDescription }
    }
    var current: Record { workspace.record("current") }
    var members: [Record] { current.rows("congressmen") }
    var parties: [Record] { current.rows("parties") }
    var motions: [Record] { current.rows("motions") }
    var motion: Record { motions.first { $0.string("id") == activeID } ?? [:] }
    var isClosed: Bool { !current.string("closedAt").isEmpty }
    var isLive: Bool { phase == "debate" || phase == "votación" }
    var votingComplete: Bool {
        phase == "votación" && !plan.isEmpty && plan.allSatisfy {
            ballots[$0.record("congressman").string("id")] != nil
        }
    }
    var counts: Record { (try? engine?.call("countBallots",[ballots])) ?? [:] }

    private func assignMissingPartyColors() -> Bool {
        func colored(_ legislature: Record) -> Record? {
            var parties = legislature.rows("parties")
            let missing = parties.indices.filter { !PartyPalette.isValid(parties[$0].string("color")) }
            guard !missing.isEmpty else { return nil }
            for index in missing {
                let color = PartyPalette.randomColor(among:parties)
                parties[index]["color"] = color
            }
            var updated = legislature
            updated["parties"] = parties
            return updated
        }
        var changed = false
        if let current = colored(current) {
            workspace["current"] = current
            changed = true
        }
        var archives = workspace.rows("archives")
        var changedArchives = false
        for index in archives.indices {
            if let term = colored(archives[index]) {
                archives[index] = term
                changedArchives = true
            }
        }
        if changedArchives { workspace["archives"] = archives }
        return changed || changedArchives
    }

    func report(_ error: Error) { self.error = error.localizedDescription }
    func save() {
        do {
            try FileManager.default.createDirectory(at: location.deletingLastPathComponent(),withIntermediateDirectories:true)
            try data().write(to:location,options:.atomic)
        } catch { report(error) }
    }
    func data() throws -> Data { try JSONSerialization.data(withJSONObject:workspace,options:[.prettyPrinted,.sortedKeys]) }
    func mutate(_ change: (inout Record) -> Void) {
        var legislature = current
        change(&legislature)
        workspace["current"] = legislature
        save()
    }
    func upsert(_ item: Record, in field: String) {
        mutate { legislature in
            var rows = legislature.rows(field)
            if let index = rows.firstIndex(where: {$0.string("id")==item.string("id")}) { rows[index] = item }
            else { rows.insert(item,at:0) }
            legislature[field] = rows
        }
    }
    func select(_ requestedID: String) {
        let id = motions.contains { $0.string("id") == requestedID } ? requestedID : ""
        guard !busy, activeID != id else { return }
        interval?.cancel()
        debateTask?.cancel()
        liveSpeech = ""
        speechQueue = []
        debatePaused = false
        activeID = id
        UserDefaults.standard.set(id,forKey:"activeMotion")
        plan = []
        ballots = [:]
        speeches = []
        paused = false
        phase = "lista"
        let saved = current.record("sessions").record(sessionID)
        if !saved.isEmpty {
            plan = saved.rows("planned")
            ballots = saved.record("votes")
            speeches = saved.rows("iosSpeeches")
            speechQueue = saved.rows("iosSpeechQueue")
            if speeches.isEmpty {
                speeches = saved.rows("debateQueue").map { item in
                    let member = item.record("congressman")
                    return ["id":member.string("id"),"partyId":member.string("partyId"),"name":member.string("name"),"text":item.string("speech")]
                }.filter { !$0.string("text").isEmpty }
            }
            phase = saved.flag("votingStarted") ? "votación" : saved.flag("debating") ? "debate" : "lista"
            paused = phase == "votación"
            debatePaused = phase == "debate" && !speechQueue.isEmpty
        }
    }
    private var sessionID: String { sessionID(for:motion) }
    private func sessionID(for item: Record) -> String {
        let request = item.record("pendingReconsideration")
        let nonce = item.number("sessionNonce")
        return request.isEmpty ? "\(item.string("id"))-\(item.rows("rounds").count)-\(nonce)" :
            "\(request.string("id"))-0-\(nonce)"
    }
    func canEditMotion(_ item: Record) -> Bool {
        guard !item.isEmpty, !isClosed, !busy, !(isLive && item.string("id") == activeID) else { return false }
        let savedSession = current.record("sessions").record(sessionID(for:item))
        guard !savedSession.flag("debating"), !savedSession.flag("votingStarted") else { return false }
        let definitive: Bool = (try? engine?.call("isMotionDefinitive",[item])) ?? item.flag("definitive")
        return !definitive
    }
    private func checkpoint() {
        guard !activeID.isEmpty else { return }
        mutate {
            var sessions = $0.record("sessions")
            sessions[sessionID] = ["planned":plan,"votes":ballots,"intermission":paused,"debating":phase=="debate","votingStarted":phase=="votación","iosSpeeches":speeches,"iosSpeechQueue":speechQueue]
            $0["sessions"] = sessions
        }
    }
    var reconsiderationIssue: String { (try? engine?.call("reconsiderationBlock",[motion,current.record("rules").number("totalSeats")])) ?? "" }
    var canStart: Bool {
        !motion.isEmpty && !isClosed && !motion.flag("definitive") && motion.string("status") != "inadmisible" &&
        (motion.rows("rounds").isEmpty || motion.flag("reconsiderationAuthorized") || !motion.record("pendingReconsideration").isEmpty)
    }
    func reconsider(_ reason: String, partyIDs: [String]) {
        guard !motion.isEmpty, reconsiderationIssue.isEmpty, !motion.flag("reconsiderationAuthorized"),
              motion.string("status") != "inadmisible", !isClosed, !busy, !isLive else { return }
        let selected = partyIDs.compactMap { id in parties.first { $0.string("id") == id } }
        let cleaned = reason.trimmingCharacters(in:.whitespacesAndNewlines)
        guard let principal = selected.first, !cleaned.isEmpty else { return }
        var item = motion
        let authors: Record = [
            "id":principal.string("id"),"type":"bancada",
            "name":selected.map { $0.string("name") }.joined(separator:" · "),
            "coSponsorPartyIds":selected.dropFirst().map { $0.string("id") }
        ]
        item["pendingReconsideration"] = ["id":"request-"+UUID().uuidString,"reason":cleaned,
            "partyId":principal.string("id"),"proposedBy":authors]
        upsert(item,in:"motions")
    }
    private var votingMotion: Record {
        var item = motion
        let request = item.record("pendingReconsideration")
        if !request.isEmpty {
            item["id"] = request.string("id")
            item["title"] = "Admisión de reconsideración · " + motion.string("title")
            item["text"] = request.string("reason") + "\n\nMoción original: " + motion.string("text")
            if !request.record("proposedBy").isEmpty {
                item["proposedBy"] = request.record("proposedBy")
            }
            item["type"] = "proyecto_ley"
            item["requiredMajority"] = "simple"
            item["rounds"] = []
        }
        return item
    }
    func begin(debate: Bool, message: String? = nil) async {
        guard let engine, !busy, canStart else { return }
        let key = APIKey.load()
        if key.isEmpty { error = "Añade tu clave de OpenAI en Ajustes."; return }
        busy = true
        defer { busy = false }
        do {
            var prepared: [Record] = plan
            if prepared.isEmpty {
                prepared = try engine.call("planSession",[members,parties,votingMotion,current.record("rules"),current.record("countryContext")])
            }
            if let message {
                if phase == "debate" && !debatePaused { toggleDebate() }
                speeches.append(["id":"mesa","name":"Mesa Directiva","text":message])
                checkpoint()
            }
            do {
                let revision: Record = ["etapa":debate ? (phase == "debate" ? "continuación del debate" : "apertura del debate") : "votación",
                    "acuerdos":motion.string("negotiations"),
                    "mensajeMesa":speeches.filter{$0.string("id")=="mesa"}.map{$0.string("text")}.joined(separator:"\n"),
                    "mensajeNuevoMesa":message ?? "", "idsOradoresPrevios":speeches.map{$0.string("id")},
                    "intervenciones":speeches.map{["id":$0.string("id"),"nombre":$0.string("name"),"texto":$0.string("text")]},
                    "votosEmitidos":ballots.mapValues{($0 as? Record)?.string("vote") ?? ""}]
                let asyncEngine = try Engine()
                let response = try await asyncEngine.simulate(["plan":prepared,"motion":votingMotion,"legislature":current,
                    "archives":workspace.rows("archives"),"debate":debate,"reconsideration": !motion.record("pendingReconsideration").isEmpty,
                    "revision":revision],key:key)
                if let closure = response["closure"] as? Record {
                    declareInadmissible(closure.string("article"),closure.string("reason"))
                    return
                }
                prepared = response.rows("ballots")
            }
            if phase == "votación" && !debate {
                for item in prepared {
                    let id = item.record("congressman").string("id")
                    let original = ballots.record(id)
                    if ["a_favor","en_contra","abstencion"].contains(original.string("vote")),
                       var updated: Record = try? engine.call("ballotOf",[item]) {
                        updated["timestamp"] = original["timestamp"]
                        updated["recordedOrder"] = original["recordedOrder"]
                        updated["partyId"] = original["partyId"]
                        ballots[id] = updated
                    }
                }
            }
            plan = prepared
            if debate {
                speechQueue = []
                liveSpeech = ""
                let shown = Set(speeches.map {$0.string("id")})
                for item in prepared {
                    let member = item.record("congressman")
                    if !item.string("speech").isEmpty && !shown.contains(member.string("id")) {
                        speechQueue.append(["id":member.string("id"),"partyId":member.string("partyId"),"name":member.string("name"),"text":item.string("speech")])
                    }
                    for event in item.rows("debateEvents") {
                        let speaker = members.first { $0.string("id") == event.string("speakerId") } ?? [:]
                        let isChair = event.string("kind") == "mesa"
                        speechQueue.append(["id":UUID().uuidString,"partyId":isChair ? "" : speaker.string("partyId"),
                            "name":isChair ? "Mesa Directiva" : speaker.isEmpty ? "Pleno" : speaker.string("name"),"text":event.string("text")])
                    }
                }
                phase = "debate"
                checkpoint()
                if !debatePaused { playDebate() }
            } else if phase == "votación" && paused { checkpoint() }
            else { rollingVote() }
        } catch { report(error) }
    }
    private func playDebate() {
        debateTask?.cancel()
        debateTask = Task {
            while phase == "debate", !debatePaused, let next = speechQueue.first {
                for character in next.string("text").dropFirst(liveSpeech.count) {
                    try? await Task.sleep(for:.milliseconds(40))
                    guard !Task.isCancelled, phase == "debate", !debatePaused else { return }
                    liveSpeech.append(character)
                }
                speeches.append(next)
                speechQueue.removeFirst()
                liveSpeech = ""
                checkpoint()
            }
        }
    }

    func toggleDebate() {
        debatePaused.toggle()
        if debatePaused { debateTask?.cancel(); checkpoint() }
        else { playDebate() }
    }

    func rollingVote() {
        guard !plan.isEmpty else { return }
        if phase == "debate" {
            debateTask?.cancel()
            if !liveSpeech.isEmpty, var interrupted = speechQueue.first {
                interrupted["text"] = liveSpeech
                speeches.append(interrupted)
            }
            liveSpeech = ""
            speechQueue = []
            debatePaused = false
        }
        if phase != "votación" {
            // Independent draw for the vote, retaining the session's timing and incidents.
            let votingCodes = ["a_favor","en_contra","abstencion"]
            let slots = plan.indices.filter { votingCodes.contains(plan[$0].string("vote")) }
            let shuffledVoters = slots.map { plan[$0] }.shuffled()
            for (slot,original) in zip(slots,shuffledVoters) {
                var voter = original
                voter["arrivalMs"] = plan[slot]["arrivalMs"]
                plan[slot] = voter
            }
        }
        phase = "votación"
        paused = false
        checkpoint()
        interval?.cancel()
        interval = Task {
            var previous = 0
            for item in plan {
                let id = item.record("congressman").string("id")
                let arrival = item.number("arrivalMs")
                if ballots[id] != nil { previous = arrival; continue }
                let gap = max(0, arrival-previous)
                if gap > 0 { try? await Task.sleep(for:.milliseconds(gap)) }
                guard !Task.isCancelled, !paused, phase == "votación" else { return }
                if var vote: Record = try? engine?.call("ballotOf",[item]) {
                    vote["recordedOrder"] = ballots.count + 1
                    vote["partyId"] = item.record("congressman").string("partyId")
                    ballots[id] = vote
                }
                previous = arrival
                checkpoint()
            }
        }
    }
    func saveNegotiation(_ text: String) async {
        guard !busy, !motion.isEmpty else { return }
        let reopeningDebate = phase == "debate"
        if reopeningDebate && !debatePaused { toggleDebate() }
        let revote = phase == "votación"
        if revote && !paused { togglePause() }
        var item = motion
        item["negotiations"] = text
        item["negotiationHistory"] = (item["negotiationHistory"] as? [String] ?? []) + [text]
        upsert(item,in:"motions")
        if reopeningDebate || revote { await begin(debate:reopeningDebate) }
    }

    func togglePause() {
        if paused { rollingVote() }
        else { paused = true; interval?.cancel(); checkpoint() }
    }
    func finish(veto: String? = nil) {
        guard let engine, phase == "votación", !busy else { return }
        interval?.cancel()
        do {
            let rules = current.record("rules")
            let subject = votingMotion
            let tie: Any = try engine.call("resolveTieBreak",[ballots,current.record("countryContext").record("board"),members])
            let tally = counts
            let validTie = subject.string("requiredMajority")=="simple" && tally.number("aFavor")==tally.number("enContra")
            let result: Record = try engine.call("evaluateVotingResult",[tally,rules,subject,validTie ? tie : NSNull()])
            var item = motion
            let appeal = item.record("pendingReconsideration")
            let authors = subject.record("proposedBy")
            let snapshot: Record = [
                "title":subject.string("title"),"text":subject.string("text"),
                "justification":subject.string("justification"),"expectedEffects":subject.string("expectedEffects"),
                "factualContext":subject.string("factualContext"),"proposedBy":authors,
                "governmentBacked":subject.flag("governmentBacked"),
                "sponsorPartyIds":([authors.string("id")]+(authors["coSponsorPartyIds"] as? [String] ?? [])).filter { !$0.isEmpty }
            ]
            let round: Record = [
                "roundNumber":item.rows("rounds").count+1,"date":ISO8601DateFormatter().string(from:.now),
                "status":veto == nil ? "completada" : "vetada","votes":ballots,"counts":tally,
                "quorumReached":result.flag("quorumReached"),"presentCount":tally.number("aFavor")+tally.number("enContra")+tally.number("abstencion")+tally.number("presentNoVote"),
                "result":result.string("result"),"debate":speeches,"negotiations":item.string("negotiations"),
                "motionSnapshot":snapshot,
                "tieBreak":validTie && result.flag("quorumReached") ? tie : NSNull()
            ]
            let oldSession = sessionID
            if appeal.isEmpty {
                item["rounds"] = item.rows("rounds") + [round]
                item["reconsiderationAuthorized"] = false
                item["status"] = veto != nil ? "vetada" : result.string("result")=="aprobada" ? "aprobada" : "rechazada"
            } else {
                item.removeValue(forKey:"pendingReconsideration")
                item["reconsiderationRequests"] = item.rows("reconsiderationRequests") + [["reason":appeal.string("reason"),"proposedBy":authors,"round":round]]
                item["reconsiderationAuthorized"] = result.string("result")=="aprobada"
                item["sessionNonce"] = item.number("sessionNonce")+1
            }
            let finalized: Record = try engine.call("finalizeMotion",[item])
            mutate {
                $0["motions"] = $0.rows("motions").map{$0.string("id")==activeID ? finalized : $0}
                var sessions = $0.record("sessions")
                sessions.removeValue(forKey:oldSession)
                $0["sessions"] = sessions
                $0["politicalDiary"] = [entry(title:subject.string("title"),text:veto ?? result.string("reasonText"),
                    type:veto != nil ? "veto_presidencial" : appeal.isEmpty ? "mocion_votada" : "reconsideracion",motionID:activeID)] + $0.rows("politicalDiary")
            }
            phase = "lista"
            plan = []
            ballots = [:]
            speeches = []
        } catch { report(error) }
    }
    func entry(title: String, text: String, type: String = "declaracion_politica", motionID: String = "") -> Record {
        ["id":UUID().uuidString,"timestamp":ISO8601DateFormatter().string(from:.now),"title":title,"description":text,"type":type,"motionId":motionID]
    }
    func declareInadmissible(_ article: String,_ reason: String) {
        interval?.cancel()
        debateTask?.cancel()
        var item = motion
        item["status"] = "inadmisible"
        item["inadmissibilityReason"] = ["ruleArticle":article,"details":reason,"issuedBy":"Mesa Directiva","constitutionalBasis":"","date":ISO8601DateFormatter().string(from:.now)]
        upsert(item,in:"motions")
        mutate { $0["politicalDiary"] = [entry(title:"Inadmisibilidad · "+item.string("title"),text:article+" · "+reason,type:"inadmisibilidad_mesa",motionID:activeID)] + $0.rows("politicalDiary") }
        phase = "lista"
        checkpoint()
    }
    func restore(_ data: Data) throws {
        guard let input = try JSONSerialization.jsonObject(with:data) as? Record, let engine else { throw CongressError(message:"Respaldo inválido.") }
        let decoded: Record = try engine.call("parseWorkspace",[input])
        guard !decoded.record("current").string("id").isEmpty else { throw CongressError(message:"El respaldo no contiene una legislatura.") }
        select("")
        workspace = decoded
        _ = assignMissingPartyColors()
        save()
    }
    func close() {
        do { guard let engine else { return }; let closed: Record = try engine.call("closeLegislature",[current]); select(""); workspace["current"] = closed; save() }
        catch { report(error) }
    }
    func open(name: String, period: String, same: Bool) {
        do { guard let engine else { return }; let next: Record = try engine.call("openLegislature",[workspace,name,period,same]); select(""); workspace = next; save() }
        catch { report(error) }
    }
    func importReform(_ item: Record, from source: Record) {
        do { guard let engine else { return }; let updated: Record = try engine.call("importReform",[current,source,item]); workspace["current"] = updated; save() }
        catch { report(error) }
    }
}
