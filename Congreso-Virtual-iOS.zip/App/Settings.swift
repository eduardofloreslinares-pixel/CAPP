import SwiftUI
import UniformTypeIdentifiers

struct DiaryView: View {
    @EnvironmentObject var store: CongressStore
    @State private var adding = false
    @State private var title = ""
    @State private var note = ""
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing:14) {
                    ForEach(store.current.rows("politicalDiary").identified) { row in
                        GlassCard {
                            Text(label(row.value.string("type"))).font(.caption.bold()).foregroundStyle(amber)
                            Text(row.value.string("title")).font(.system(.title3,design:.serif,weight:.semibold))
                            Text(row.value.string("description")).font(.callout).textSelection(.enabled)
                            if let date = ISO8601DateFormatter().date(from:row.value.string("timestamp")) {
                                Text(date.formatted(date:.abbreviated,time:.shortened)).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                }.padding(16)
            }
            .background { PageBackground() }
            .navigationTitle("Diario")
            .toolbar { Button("Nueva entrada",systemImage:"square.and.pencil") { title=""; note=""; adding=true }.disabled(store.isClosed) }
            .sheet(isPresented:$adding) {
                NavigationStack {
                    Form {
                        TextField("Título",text:$title)
                        TextField("Registro",text:$note,axis:.vertical).lineLimit(4...14)
                    }
                    .navigationTitle("Nueva entrada")
                    .toolbar {
                        ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { adding=false } }
                        ToolbarItem(placement:.confirmationAction) {
                            Button("Guardar") { store.upsert(store.entry(title:title,text:note),in:"politicalDiary"); adding=false }
                                .disabled(title.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || note.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                        }
                    }
                }
            }
        }
    }
}
struct Backup: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    let bytes: Data
    init(bytes: Data) { self.bytes=bytes }
    init(configuration: ReadConfiguration) throws {
        guard let data=configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        bytes=data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents:bytes) }
}
struct SettingsView: View {
    @EnvironmentObject var store: CongressStore
    @State private var key = ""
    @State private var showingImport = false
    @State private var showingExport = false
    @State private var backup: Backup?
    @State private var closePrompt = false
    @State private var name = ""
    @State private var period = ""
    @State private var same = true
    var body: some View {
        NavigationStack {
            Form {
                Section("GPT-6 Luna") {
                    SecureField("Clave API de OpenAI",text:$key).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("Guardar clave") {
                        do { try APIKey.save(key.trimmingCharacters(in:.whitespacesAndNewlines)) }
                        catch { store.report(error) }
                    }
                }
                Section("Legislatura") {
                    NavigationLink("Reglas y contexto") { RulesEditor(legislature:store.current) }
                    NavigationLink("Archivo legislativo") { ArchiveView() }
                    if store.isClosed {
                        TextField("Nombre de la nueva legislatura",text:$name)
                        TextField("Período",text:$period)
                        Toggle("Conservar las bancadas y curules",isOn:$same)
                        Button("Abrir legislatura") { store.open(name:name,period:period,same:same) }
                            .disabled(name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || period.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                    } else {
                        Button("Cerrar legislatura",role:.destructive) { closePrompt=true }.disabled(store.busy || store.isLive)
                    }
                }
                Section("Respaldo") {
                    Button("Exportar respaldo",systemImage:"square.and.arrow.up") {
                        do { backup=Backup(bytes:try store.data()); showingExport=true }
                        catch { store.report(error) }
                    }
                    Button("Importar respaldo",systemImage:"square.and.arrow.down") { showingImport=true }.disabled(store.busy || store.isLive)
                    Text("Puedes importar el JSON exportado por Congreso Virtual en Android.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Ajustes")
            .onAppear { key=APIKey.load() }
            .confirmationDialog("¿Cerrar la legislatura?",isPresented:$closePrompt,titleVisibility:.visible) {
                Button("Cerrar legislatura",role:.destructive) { store.close() }
            }
            .fileExporter(isPresented:$showingExport,document:backup,contentType:.json,defaultFilename:"Congreso-respaldo") { result in
                if case .failure(let error)=result { store.report(error) }
            }
            .fileImporter(isPresented:$showingImport,allowedContentTypes:[.json]) { result in
                do {
                    let url = try result.get()
                    let authorized=url.startAccessingSecurityScopedResource()
                    defer { if authorized { url.stopAccessingSecurityScopedResource() } }
                    try store.restore(Data(contentsOf:url))
                } catch { store.report(error) }
            }
        }
    }
}
struct RulesEditor: View {
    @EnvironmentObject var store: CongressStore
    @Environment(\.dismiss) private var dismiss
    let legislature: Record
    @State private var name = ""
    @State private var period = ""
    @State private var president = ""
    @State private var political = ""
    @State private var ruleText = ""
    @State private var economic = "estable"
    @State private var tension = "media"
    @State private var approval = 50.0
    @State private var seats = 51
    @State private var quorum = 26
    @State private var quorumType = "mitad_mas_uno"
    @State private var board: [String:String] = [:]
    @State private var thresholds: [String:String] = [:]
    let thresholdFields = [("ordinary","Proyectos de ley"),("constitutionalReform","Reforma constitucional"),("vacancia","Vacancia"),("desafuero","Desafuero"),("censura","Censura")]
    var body: some View {
        Form {
            Section("Legislatura y Ejecutivo") {
                TextField("Nombre",text:$name)
                TextField("Período",text:$period)
                TextField("Presidencia del Ejecutivo",text:$president)
                LabeledContent("Aprobación presidencial",value:"\(Int(approval)) %")
                Slider(value:$approval,in:0...100,step:1)
                TextField("Contexto político",text:$political,axis:.vertical)
                Picker("Economía",selection:$economic) { ForEach(["crisis","estancamiento","estable","crecimiento"],id:\.self) {Text(label($0)).tag($0)} }
                Picker("Tensión social",selection:$tension) { ForEach(["baja","media","alta","crítica"],id:\.self) {Text(label($0)).tag($0)} }
            }
            Section("Reglamento") {
                TextField("Escaños legales",value:$seats,format:.number).keyboardType(.numberPad)
                Picker("Cuórum",selection:$quorumType) {
                    Text("Mitad más uno").tag("mitad_mas_uno")
                    Text("Dos tercios").tag("dos_tercios")
                    Text("Número fijo").tag("numero_fijo")
                }
                if quorumType=="numero_fijo" { TextField("Mínimo de presentes",value:$quorum,format:.number).keyboardType(.numberPad) }
                ForEach(thresholdFields,id:\.0) { field in
                    Picker(field.1,selection:Binding(get:{thresholds[field.0] ?? "simple"},set:{thresholds[field.0]=$0})) {
                        ForEach(majorities,id:\.0) { Text($0.1).tag($0.0) }
                    }
                }
                TextField("Reglamento del Congreso",text:$ruleText,axis:.vertical).lineLimit(4...12)
            }
            Section("Mesa Directiva") {
                ForEach([("president","Presidencia"),("vicePresident1","Primera vicepresidencia"),("vicePresident2","Segunda vicepresidencia")],id:\.0) { field in
                    Picker(field.1,selection:Binding(get:{board[field.0] ?? ""},set:{board[field.0]=$0})) {
                        Text("Sin designar").tag("")
                        ForEach(store.members.identified) { Text($0.value.string("name")).tag($0.id) }
                    }
                }
            }
        }
        .disabled(store.isClosed || store.busy || store.isLive)
        .navigationTitle("Reglas y contexto")
        .toolbar {
            ToolbarItem(placement:.confirmationAction) {
                Button("Guardar") { save() }.disabled(store.isClosed || store.busy || store.isLive || name.isEmpty || seats<1 || (quorumType=="numero_fijo" && (quorum<1 || quorum>seats)))
            }
        }
        .onAppear {
            let context=legislature.record("countryContext")
            let rules=legislature.record("rules")
            name=legislature.string("name"); period=legislature.string("period"); president=context.string("presidentName")
            approval=Double(context.number("executiveApproval")); political=context.string("politicalDescription")
            economic=context.string("economicStatus"); tension=context.string("socialTension"); ruleText=context.string("congressionalRules")
            seats=rules.number("totalSeats"); quorum=rules.number("quorumNumber"); quorumType=rules.string("quorumType")
            board=context["board"] as? [String:String] ?? [:]; thresholds=rules["majorityThresholds"] as? [String:String] ?? [:]
        }
    }
    func save() {
        let officers=board.values.filter{!$0.isEmpty}
        guard Set(officers).count==officers.count else { store.error="Designa a una persona distinta para cada cargo."; return }
        store.mutate {
            $0["name"]=name; $0["period"]=period
            var rules=$0.record("rules")
            rules.merge(["totalSeats":seats,"quorumNumber":quorum,"quorumType":quorumType,"majorityThresholds":thresholds]) { _,new in new }
            $0["rules"]=rules
            var context=$0.record("countryContext")
            context.merge(["presidentName":president,"executiveApproval":Int(approval),"politicalDescription":political,
                "economicStatus":economic,"socialTension":tension,"congressionalRules":ruleText,
                "board":board.filter{!$0.value.isEmpty}]) { _,new in new }
            $0["countryContext"]=context
        }
        dismiss()
    }
}
struct ArchiveView: View {
    @EnvironmentObject var store: CongressStore
    var body: some View {
        List(store.workspace.rows("archives").identified) { term in
            NavigationLink(term.value.string("name")) {
                ScrollView {
                    VStack(spacing:16) {
                        ForEach(term.value.rows("motions").identified) { row in
                            GlassCard {
                                Text(row.value.string("title")).font(.headline)
                                Text(row.value.string("text")).font(.callout)
                                if row.value.string("type")=="reforma_constitucional" && row.value.string("status")=="aprobada" && !store.isClosed {
                                    Button("Importar reforma") { store.importReform(row.value,from:term.value) }.buttonStyle(.glass)
                                }
                            }
                            RoundHistory(motion:row.value,members:term.value.rows("congressmen"))
                        }
                    }.padding(16)
                }.navigationTitle(term.value.string("name"))
            }
        }.navigationTitle("Archivo")
    }
}
