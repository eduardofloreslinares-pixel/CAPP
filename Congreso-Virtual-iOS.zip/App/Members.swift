import SwiftUI
import UIKit

enum PartyPalette {
    private static let colors = ["#BD2548","#B55217","#00846D","#2463AD","#815729","#384C93","#8045A8","#9B316A","#427438","#007D96","#A53481","#9D6610"]

    static func isValid(_ color: String) -> Bool {
        color.hasPrefix("#") && color.count == 7 && UInt32(color.dropFirst(),radix:16) != nil
    }

    static func randomColor(among parties: [Record]) -> String {
        let used = Set(parties.map { $0.string("color").uppercased() })
        return colors.filter { !used.contains($0) }.randomElement() ?? colors.randomElement() ?? "#2463AD"
    }

    static func hex(_ color: Color) -> String? {
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        guard UIColor(color).getRed(&red,green:&green,blue:&blue,alpha:&alpha) else { return nil }
        let channels = [red,green,blue].map { Int((min(1,max(0,$0))*255).rounded()) }
        return String(format:"#%02X%02X%02X",channels[0],channels[1],channels[2])
    }
}

struct MembersView: View {
    @EnvironmentObject var store: CongressStore
    @State private var search = ""
    @State private var addingParty = false
    @State private var addingMember = false
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.parties.identified) { row in
                    let group = store.members.filter{$0.string("partyId")==row.id}
                    let filtered = group.filter{search.isEmpty || $0.string("name").localizedCaseInsensitiveContains(search)}
                    if search.isEmpty || !filtered.isEmpty {
                        Section {
                            ForEach(filtered.identified) { member in
                                NavigationLink {
                                    PersonEditor(existing:member.value,party:false)
                                } label: {
                                    HStack(spacing:12) {
                                        Image(systemName:"person.crop.circle.fill").font(.title2).foregroundStyle(Color(hex:row.value.string("color")))
                                        VStack(alignment:.leading) {
                                            Text(member.value.string("name")).font(.headline)
                                            Text(member.value.string("personality")+" · "+member.value.string("ideology")).font(.caption).foregroundStyle(.secondary)
                                        }
                                    }.padding(.vertical,3)
                                }
                            }
                        } header: {
                            NavigationLink {
                                PersonEditor(existing:row.value,party:true)
                            } label: {
                                HStack {
                                    Circle().fill(Color(hex:row.value.string("color"))).frame(width:8,height:8)
                                    Text(row.value.string("name"))
                                    Spacer()
                                    Text("\(group.count)")
                                    Image(systemName:"chevron.right")
                                }
                            }.textCase(nil)
                        }
                    }
                }
            }
            .navigationTitle("Bancadas")
            .searchable(text:$search,prompt:"Buscar congresista")
            .toolbar {
                ToolbarItem(placement:.topBarTrailing) {
                    Menu("Añadir",systemImage:"plus") {
                        Button("Bancada") { addingParty=true }
                        Button("Congresista") { addingMember=true }.disabled(store.parties.isEmpty)
                    }.disabled(store.isClosed || store.busy || store.isLive)
                }
            }
            .sheet(isPresented:$addingParty) { NavigationStack { PersonEditor(existing:[:],party:true) } }
            .sheet(isPresented:$addingMember) { NavigationStack { PersonEditor(existing:[:],party:false) } }
        }
    }
}
struct PersonEditor: View {
    @EnvironmentObject var store: CongressStore
    @Environment(\.dismiss) private var dismiss
    let existing: Record
    let party: Bool
    @State private var name = ""
    @State private var shortName = ""
    @State private var ideology = ""
    @State private var description = ""
    @State private var group = ""
    @State private var personality = ""
    @State private var stance = "independiente"
    @State private var region = ""
    @State private var loyalty = 70.0
    @State private var attendance = 95.0
    @State private var disruption = 3.0
    @State private var color = ""
    @State private var axes: [String:Double] = [:]
    var body: some View {
        Form {
            Section("Perfil") {
                TextField("Nombre",text:$name)
                TextField("Ideología",text:$ideology)
                if party {
                    TextField("Sigla",text:$shortName)
                    ColorPicker("Color de la bancada",selection:Binding(
                        get:{Color(hex:color)},
                        set:{if let hex = PartyPalette.hex($0) { color = hex }}
                    ),supportsOpacity:false)
                    Picker("Relación con el Ejecutivo",selection:$stance) {
                        ForEach(["oficialista","aliado","independiente","oposicion_moderada","oposicion_dura"],id:\.self) { Text(label($0)).tag($0) }
                    }
                    TextField("Descripción",text:$description,axis:.vertical)
                } else {
                    Picker("Bancada",selection:$group) { ForEach(store.parties.identified) { Text($0.value.string("shortName")).tag($0.id) } }
                    TextField("Personalidad",text:$personality)
                    TextField("Circunscripción",text:$region)
                    LabeledContent("Asistencia",value:"\(Int(attendance)) %")
                    Slider(value:$attendance,in:0...100,step:1)
                    LabeledContent("Probabilidad de incidente",value:"\(Int(disruption)) %")
                    Slider(value:$disruption,in:0...100,step:1)
                }
                LabeledContent(party ? "Disciplina de bancada" : "Lealtad",value:"\(Int(loyalty)) %")
                Slider(value:$loyalty,in:0...100,step:1)
            }
            Section("Posiciones") { AxisSliders(values:$axes) }
        }
        .disabled(store.isClosed || store.busy || store.isLive)
        .navigationTitle(party ? "Bancada" : "Congresista")
        .toolbar {
            ToolbarItem(placement:.confirmationAction) { Button("Guardar") { save() }.disabled(store.isClosed || store.busy || store.isLive || name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || (party ? shortName.isEmpty : group.isEmpty)) }
        }
        .onAppear {
            name=existing.string("name"); ideology=existing.string("ideology")
            shortName=existing.string("shortName"); description=existing.string("description")
            group=existing.string("partyId"); personality=existing.string("personality")
            region=existing.string("region")
            if party && color.isEmpty {
                let saved = existing.string("color")
                color = PartyPalette.isValid(saved) ? saved : PartyPalette.randomColor(among:store.parties)
            }
            if existing.isEmpty {
                group=store.parties.first?.string("id") ?? ""
                if !party, let selected=store.parties.first { axes=selected.record("decisionWeights").compactMapValues{($0 as? NSNumber)?.doubleValue} }
            } else {
                loyalty=Double(existing.number(party ? "partyDiscipline":"loyalty"))
                attendance=Double(existing.number("attendanceProbability"))
                disruption=Double(existing.number("disruptionProbability"))
                axes=existing.record(party ? "decisionWeights":"positions").compactMapValues{($0 as? NSNumber)?.doubleValue}
                if party { stance=existing.string("stanceTowardsGovernment") }
            }
        }
    }
    func save() {
        var item = existing
        if item.isEmpty { item["id"]=UUID().uuidString }
        let values = Dictionary(uniqueKeysWithValues:positions.map{($0.0,Int(axes[$0.0] ?? 50))})
        item["name"]=name
        item["ideology"]=ideology.isEmpty ? "Centro" : ideology
        if party {
            item.merge(["shortName":shortName,"decisionWeights":values,"partyDiscipline":Int(loyalty),"description":description,"color":color,"stanceTowardsGovernment":stance]) { _,new in new }
        } else {
            let usedSeats = store.members.map { $0.number("seatIndex") }
            item.merge(["partyId":group,"positions":values,"loyalty":Int(loyalty),"personality":personality.isEmpty ? "Pragmático":personality,
                        "region":region,"attendanceProbability":Int(attendance),"disruptionProbability":Int(disruption),
                        "seatIndex":existing.isEmpty ? (usedSeats.max() ?? -1)+1:existing.number("seatIndex"),
                        "votingHistory":existing.rows("votingHistory"),"allies":existing["allies"] ?? [],"rivals":existing["rivals"] ?? [],"personalAdjustments":existing.record("personalAdjustments")]) { _,new in new }
        }
        store.upsert(item,in:party ? "parties":"congressmen")
        dismiss()
    }
}
