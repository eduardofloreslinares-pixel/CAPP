import SwiftUI

struct AgendaView: View {
    @EnvironmentObject var store: CongressStore
    var showPleno: () -> Void
    @State private var filter = "todas"
    @State private var search = ""
    @State private var editing = false
    @State private var draft: Record = [:]
    var visible: [Record] {
        store.motions.filter {
            (filter=="todas" || $0.string("type")==filter) &&
            (search.isEmpty || $0.string("title").localizedCaseInsensitiveContains(search))
        }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing:15) {
                    if visible.isEmpty { ContentUnavailableView("Sin mociones",systemImage:"doc.text",description:Text("Las iniciativas de esta legislatura aparecerán aquí.")) }
                    ForEach(visible.identified) { row in
                        let item = row.value
                        GlassCard {
                            HStack {
                                Text(label(item.string("type"))).font(.caption.bold()).foregroundStyle(amber)
                                Spacer()
                                Text(label(item.string("status"))).font(.caption.weight(.medium)).foregroundStyle(.secondary)
                            }
                            Text(item.string("title")).font(.system(.title3,design:.serif,weight:.semibold))
                            Text(item.record("proposedBy").string("name")).font(.subheadline).foregroundStyle(.secondary)
                            HStack {
                                Button("Pasar al pleno",systemImage:"arrow.up.left") { store.select(item.string("id")); showPleno() }.buttonStyle(.glass).disabled(store.busy)
                                if store.canEditMotion(item) {
                                    Button("Editar",systemImage:"pencil") { draft=item; editing=true }.buttonStyle(.glass)
                                }
                            }
                        }
                    }
                }.padding(16)
            }
            .background { PageBackground() }
            .navigationTitle("Agenda")
            .searchable(text:$search,prompt:"Buscar mociones")
            .toolbar {
                ToolbarItem(placement:.topBarLeading) {
                    Menu("Filtrar",systemImage:"line.3.horizontal.decrease") {
                        Picker("Tipo",selection:$filter) {
                            Text("Todas").tag("todas")
                            ForEach(motionTypes,id:\.0) { entry in Text(entry.1).tag(entry.0) }
                        }
                    }
                }
                ToolbarItem(placement:.topBarTrailing) {
                    Button("Nueva moción",systemImage:"plus") { draft=[:]; editing=true }
                        .disabled(store.isClosed || store.parties.isEmpty || store.busy)
                }
            }
            .sheet(isPresented:$editing) { MotionEditor(existing:draft) }
        }
    }
}

// Stable identities for JSON rows, including Android backups.
struct JSONRow: Identifiable {
    let value: Record
    var id: String { value.string("id") }
}
extension Array where Element == Record {
    var identified: [JSONRow] { map(JSONRow.init(value:)) }
}

struct MotionEditor: View {
    @EnvironmentObject var store: CongressStore
    @Environment(\.dismiss) private var dismiss
    let existing: Record
    @State private var title = ""
    @State private var text = ""
    @State private var justification = ""
    @State private var factualContext = ""
    @State private var effects = ""
    @State private var kind = "proyecto_ley"
    @State private var majority = "simple"
    @State private var priority = "media"
    @State private var sponsor = ""
    @State private var individual = false
    @State private var cosponsors: Set<String> = []
    @State private var backing = false
    @State private var impact: [String:Double] = [:]
    var body: some View {
        NavigationStack {
            Form {
                Section("Iniciativa") {
                    TextField("Título de la moción",text:$title,axis:.vertical).lineLimit(1...3)
                    VStack(alignment:.leading,spacing:6) {
                        Text("Considerandos").font(.subheadline.weight(.semibold))
                        TextField("Que…",text:$justification,axis:.vertical).lineLimit(8...20)
                            .accessibilityLabel("Considerandos")
                    }
                    VStack(alignment:.leading,spacing:6) {
                        Text("Resolución propuesta").font(.subheadline.weight(.semibold))
                        TextField("1. Declarar…",text:$text,axis:.vertical).lineLimit(3...7)
                            .accessibilityLabel("Resolución propuesta")
                    }
                    VStack(alignment:.leading,spacing:6) {
                        Text("Efectos esperados").font(.subheadline.weight(.semibold))
                        TextField("Resumen objetivo de lo que ocurre si se aprueba",text:$effects,axis:.vertical)
                            .lineLimit(2...5).accessibilityLabel("Efectos esperados")
                    }
                }
                Section {
                    TextField("Hechos y antecedentes",text:$factualContext,axis:.vertical)
                        .lineLimit(3...10)
                } header: {
                    Text("Contexto de la moción")
                } footer: {
                    Text("La IA tomará estos hechos como ciertos dentro de la simulación.")
                }
                Section("Trámite") {
                    Picker("Tipo",selection:Binding(get:{kind},set:{kind=$0; setMajority()})) { ForEach(motionTypes,id:\.0) { item in Text(item.1).tag(item.0) } }
                    Picker("Mayoría",selection:$majority) { ForEach(majorities,id:\.0) { item in Text(item.1).tag(item.0) } }
                    Picker("Prioridad",selection:$priority) { ForEach(["baja","media","alta"],id:\.self) { Text(label($0)).tag($0) } }
                    Toggle("Respaldo del Ejecutivo",isOn:$backing)
                }
                Section("Autoría") {
                    Toggle("A título individual",isOn:$individual)
                    Picker("Proponente",selection:$sponsor) {
                        ForEach((individual ? store.members : store.parties).identified) { Text($0.value.string("name")).tag($0.id) }
                    }
                    if !individual {
                        let available = store.parties.identified.filter { $0.id != sponsor }
                        let selected = available.filter { cosponsors.contains($0.id) }
                        Menu {
                            ForEach(available) { party in
                                Toggle(party.value.string("name"),isOn:Binding(get:{cosponsors.contains(party.id)},set:{ checked in
                                    if checked { cosponsors.insert(party.id) } else { cosponsors.remove(party.id) }
                                }))
                            }
                        } label: {
                            LabeledContent("Bancadas copatrocinadoras") {
                                Label(selected.isEmpty ? "Elegir" : selected.map { $0.value.string("shortName") }.joined(separator:", "),
                                      systemImage:"chevron.up.chevron.down")
                                .font(.subheadline)
                            }
                        }
                        .menuActionDismissBehavior(.disabled)
                        .disabled(available.isEmpty)
                    }
                }
            }
            .navigationTitle(existing.isEmpty ? "Nueva moción" : "Editar moción")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement:.cancellationAction) { Button("Cancelar",role:.cancel) { dismiss() } }
                ToolbarItem(placement:.confirmationAction) { Button("Guardar") { save() }.disabled(title.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || sponsor.isEmpty) }
            }
            .onAppear {
                title=existing.string("title"); text=existing.string("text"); justification=existing.string("justification")
                factualContext=existing.string("factualContext")
                effects=existing.string("expectedEffects"); backing=existing.flag("governmentBacked")
                individual=existing.record("proposedBy").string("type")=="congresista"
                sponsor=existing.record("proposedBy").string("id")
                if sponsor.isEmpty { sponsor=store.parties.first?.string("id") ?? "" }
                cosponsors=Set(existing.record("proposedBy")["coSponsorPartyIds"] as? [String] ?? [])
                if !existing.isEmpty {
                    kind=existing.string("type"); majority=existing.string("requiredMajority"); priority=existing.string("priority")
                    impact=existing.record("policyImpacts").compactMapValues { ($0 as? NSNumber)?.doubleValue }
                } else { setMajority() }
            }
            .onChange(of:individual) { _, individual in
                let candidates = individual ? store.members : store.parties
                if !candidates.contains(where:{$0.string("id")==sponsor}) { sponsor=candidates.first?.string("id") ?? "" }
            }
        }
    }
    func setMajority() {
        let keys = ["vacancia":"vacancia","desafuero":"desafuero","reforma_constitucional":"constitutionalReform","censura_mesa_directiva":"censura","censura_ministro":"censura"]
        let configured = store.current.record("rules").record("majorityThresholds").string(keys[kind] ?? "ordinary")
        majority = configured.isEmpty ? "simple" : configured
    }
    func save() {
        guard !store.isClosed, !store.busy else { return }
        let rows = individual ? store.members : store.parties
        guard let author = rows.first(where:{$0.string("id")==sponsor}) else { return }
        var item: Record
        if existing.isEmpty {
            item = ["id":"motion-"+UUID().uuidString,"rounds":[],"currentRoundIndex":0,"status":"borrador"]
        } else {
            guard let latest = store.motions.first(where: { $0.string("id") == existing.string("id") }),
                  store.canEditMotion(latest) else {
                store.error = "La moción ya no está disponible para editar."
                return
            }
            item = latest
        }
        let co = individual ? [] : store.parties.filter { $0.string("id") != sponsor && cosponsors.contains($0.string("id")) }
        item.merge(["title":title,"text":text,"justification":justification,"expectedEffects":effects,"governmentBacked":backing,
            "factualContext":factualContext.trimmingCharacters(in:.whitespacesAndNewlines),
            "type":kind,"priority":priority,"requiredMajority":majority,
            "policyImpacts":Dictionary(uniqueKeysWithValues:positions.map{($0.0,Int(impact[$0.0] ?? 50))}),
            "proposedBy":["id":sponsor,"type":individual ? "congresista":"bancada","name":([author]+co).map{$0.string("name")}.joined(separator:" · "),"coSponsorPartyIds":co.map{$0.string("id")}]
        ]) { _,new in new }
        store.upsert(item,in:"motions")
        dismiss()
    }
}
struct AxisSliders: View {
    @Binding var values: [String:Double]
    var body: some View {
        ForEach(positions,id:\.0) { axis in
            VStack(alignment:.leading) {
                HStack { Text(axis.1); Spacer(); Text(Int(values[axis.0] ?? 50).formatted()).monospacedDigit().foregroundStyle(.secondary) }
                Slider(value:Binding(get:{values[axis.0] ?? 50},set:{values[axis.0]=$0}),in:0...100,step:1)
            }
        }
    }
}
