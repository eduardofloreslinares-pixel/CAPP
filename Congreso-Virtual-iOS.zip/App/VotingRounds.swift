import Foundation

struct VotingRoundEntry: Identifiable {
    let id: String
    let number: Int
    let kind: String?
    let round: Record
    let request: Record?

    var title: String {
        let base = "Ronda \(number)"
        return kind.map { base + " (" + $0 + ")" } ?? base
    }

    static func history(for motion: Record) -> [Self] {
        let rounds = motion.rows("rounds")
        let requests = motion.rows("reconsiderationRequests")
        var history: [Self] = []
        var nextMotionRound = 0

        func appendMotionRound() {
            guard rounds.indices.contains(nextMotionRound) else { return }
            let index = nextMotionRound
            history.append(Self(id:"mocion-\(index)",number:history.count+1,
                kind:index == 0 ? nil : "Reconsideración",round:rounds[index],request:nil))
            nextMotionRound += 1
        }

        appendMotionRound()
        for (index,request) in requests.enumerated() {
            let round = request.record("round")
            guard !round.isEmpty else { continue }
            history.append(Self(id:"admision-\(index)",number:history.count+1,
                kind:"Admisión de reconsideración",round:round,request:request))
            // Legacy backups stored admissions separately, sometimes with duplicate round numbers.
            if round.string("result") == "aprobada" { appendMotionRound() }
        }
        while nextMotionRound < rounds.count { appendMotionRound() }
        return history
    }

    static func title(for motion: Record) -> String {
        let history = history(for:motion)
        let base = "Ronda \(history.count + 1)"
        if !motion.record("pendingReconsideration").isEmpty { return base + " (Admisión de reconsideración)" }
        if !motion.rows("rounds").isEmpty { return base + " (Reconsideración)" }
        return base
    }
}
